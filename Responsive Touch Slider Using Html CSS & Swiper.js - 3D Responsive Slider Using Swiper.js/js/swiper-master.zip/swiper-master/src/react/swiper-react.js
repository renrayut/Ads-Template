import { Swiper } from './swiper.js';
import { SwiperSlide } from './swiper-slide.js';

export { Swiper, SwiperSlide };
