module.exports.outputDir = 'dist';
